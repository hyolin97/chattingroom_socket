import java.awt.*;
import java.awt.List;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.EtchedBorder;
import java.io.*;
import java.net.Socket;

public class Client extends JFrame implements ActionListener{
    private JTextArea txtarea = new JTextArea();
    private JScrollPane jScrollPane1 = new JScrollPane();
    private JTextField txtsend = new JTextField();
    private JButton btnok = new JButton();
    private JButton btnclose = new JButton();
    private List list = new List();
    private JLabel jLabel1 = new JLabel();
    private JTextField txtname = new JTextField();
    private JButton btnconn = new JButton();
    private BufferedReader in;
    private OutputStream output;
    private PrintWriter out;
    private Socket socket;
    String inputLine;
    int count = 0;

    public Client() {
        try {
            jbInit();
            addListener();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void jbInit() throws Exception {
        this.getContentPane().setLayout(null);
        this.setSize(new Dimension(652, 264));

        this.setTitle("ä�� ���α׷�");
        this.setBackground(new Color(250, 150, 205));
        jLabel1.setText("�̸�:");
        jLabel1.setBounds(new Rectangle(15, 10, 45, 25));
        txtname.setBounds(new Rectangle(60, 10, 105, 25));
        txtname.setBackground(new Color(222 ,239 ,252));
        btnconn.setText("����");
        btnconn.setBounds(new Rectangle(165, 10, 60, 25));

        txtsend.setBounds(new Rectangle(15, 200, 375, 25));
        txtsend.setBackground(new Color(222 ,239 ,252));
        btnok.setText("Ȯ��");
        btnok.setBounds(new Rectangle(390, 200, 60, 25));
        btnclose.setText("out");
        btnclose.setBounds(new Rectangle(450, 200, 60, 25));
        list.setBounds(new Rectangle(525, 40, 110, 120));
        this.getContentPane().add(btnclose, null);
        jScrollPane1.setBounds(new Rectangle(15, 40, 495, 155));
        this.getContentPane().add(btnok, null);
        this.getContentPane().add(txtsend, null);
        jScrollPane1.getViewport().add(txtarea, null);
        txtarea.setBackground(new Color(222 ,239 ,252));
     this.getContentPane().setBackground(new Color(250,205,216));
        this.getContentPane().add(jScrollPane1, null);
        this.getContentPane().add(btnconn, null);
        this.getContentPane().add(txtname, null);
        this.getContentPane().add(jLabel1, null);
    }

    public void addListener() {
        txtname.addActionListener(this);
        btnconn.addActionListener(this);
        txtsend.addActionListener(this);
        btnok.addActionListener(this);
        btnclose.addActionListener(this);

    }

    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == txtname || e.getSource() == btnconn) {
            //��ȭ�� �Է� �� ����
            String name=txtname.getText();
            txtarea.setText(name+"���� �����Ͽ����ϴ�.\n");
            if (txtname.getText().equals("")) {
                JOptionPane.showMessageDialog(this, "��ȭ�� �Է�");
                txtname.requestFocus();
                return;
            }

            Thread worker = new Thread() {
                public void run() {//192.168.40.184
                    try {
                        socket = new Socket("192.168.50.14", 7777);
                        out = new PrintWriter(socket.getOutputStream(), true);
                        in = new BufferedReader(new InputStreamReader(
                                socket.getInputStream()));

                        out.print(txtname.getText() + "\n");
                        out.flush();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    while (true) {
                        try {
                            inputLine = in.readLine();
                            txtarea.append("\n" + inputLine);

                        } catch (Exception e) {
                            e.printStackTrace();
                        }


                    }


                }

            };

            worker.start();

        }else if(e.getSource() == txtsend || e.getSource() == btnok) {
            //�޼��� ����

            new Thread() {
                public void run() {
                    String data = txtsend.getText().toString();
                    if (data != null) {
                        out.print(data + "\n");
                        out.flush();
                    }

                }
            }.start();

        }else if(e.getSource() == btnclose) {
            //������
            try {
                in.close();
                out.close();
                socket.close();
                System.exit(0);
            } catch (Exception e2) {
                System.out.println("������ ����:" + e2);
            } finally {
                System.exit(0);
            }
        }
    }

    public static void main(String args[]) {
        Client fr = new Client();
        fr.getPreferredSize();
        fr.setBackground(new Color(250, 150, 205));
        fr.setLocation(200, 200);
        fr.setVisible(true);
        fr.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

}